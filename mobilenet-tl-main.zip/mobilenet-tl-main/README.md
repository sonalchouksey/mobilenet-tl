# mobilenet-tl

Deployment of a MobileNetV2(Transfer Learning) model with pre-trained weights on Heroku

Use !pipreqs /content for getting requirements.txt


#IMPORTANT NOTE: 

1. Change Tensorflow to tensorflow-cpu ( If you get Slug Size Error)
2. Change opencv-python to opencv-contrib-python-headless
3. Add h5py<3.0.0
